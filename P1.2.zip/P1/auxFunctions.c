#include "fileList.h"

void aux_getDirectory(char *tr[], int *lng, int *acc, int *lnk, int *idx){
    int i = 0;
    for (; tr[i] != NULL && tr[i][0] == '-'; i++) {
        if (strcmp(tr[i], "-long") == 0) *lng = 1;
        else if (strcmp(tr[i], "-acc") == 0) *acc = 1;
        else if (strcmp(tr[i], "-link") == 0) *lnk = 1;
        else {
            printf("sso: argumento no válido. Use (-long)(-link)(-acc)\n");
            return;
        }
    }
    *idx = i; //indice de inicio de los directorios
}

void aux_printFileInfo(struct dirent *file, struct stat *st, int lng, int acc, int lnk){
    // -acc
    if (acc) {
        char timebuf[80];
        strftime(timebuf, sizeof(timebuf), "%Y/%m/%d-%H:%M", localtime(&st->st_atime));
        printf("%s\t", timebuf);
    }


    printf("%ld ", (long)st->st_nlink);
    printf("(%ld)\t", (long)st->st_ino);

    // propietario archivo
    struct passwd *pwd = getpwuid(st->st_uid);
    printf("%s\t", pwd ? pwd->pw_name : "???");

    // grupo
    struct group *grp = getgrgid(st->st_gid);
    printf("%s\t", grp ? grp->gr_name : "??????");
    
    // -long
    if (lng) {
        printf("%c%c%c%c%c%c%c%c%c%c\t", 
        (S_ISDIR(st->st_mode)) ? 'd' : '-', 
        (st->st_mode & S_IRUSR) ? 'r' : '-', 
        (st->st_mode & S_IWUSR) ? 'w' : '-', 
        (st->st_mode & S_IXUSR) ? 'x' : '-', 
        (st->st_mode & S_IRGRP) ? 'r' : '-', 
        (st->st_mode & S_IWGRP) ? 'w' : '-', 
        (st->st_mode & S_IXGRP) ? 'x' : '-', 
        (st->st_mode & S_IROTH) ? 'r' : '-', 
        (st->st_mode & S_IWOTH) ? 'w' : '-', 
        (st->st_mode & S_IXOTH) ? 'x' : '-'
        );
    }
    // tamaño bloque
    printf("%lld ", (long long)st->st_size);

    // -link
    if (lnk && S_ISLNK(st->st_mode)) {
        char link_target[512];
        ssize_t len = readlink(file->d_name, link_target, sizeof(link_target) - 1);
        if (len != -1) { 
            link_target[len] = '\0'; 
            printf(" -> %s\n", link_target); 
        }
    }
    printf("\n");
}

void aux_listFilesInDir(const char *DIRname, int lng, int acc, int lnk){
    DIR *cdir = opendir(DIRname);
    struct dirent *cfile;
    struct stat cstat;
    char buffer[512];

    if (cdir == NULL) {
        printf("sso: No se pudo abrir el directorio %s\n", DIRname);
        return;
    }
    while ((cfile = readdir(cdir)) != NULL) {
        snprintf(buffer, sizeof(buffer), "%s/%s", DIRname, cfile->d_name);
        if (lstat(buffer, &cstat) == 0) {
            aux_printFileInfo(cfile, &cstat, lng, acc, lnk);
        }
    }
    closedir(cdir);
}
