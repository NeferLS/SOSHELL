#pragma once
#include "types.h"

void aux_getDirectory(char *tr[], int *lng, int *acc, int *lnk, int *idx);
void aux_listFilesInDir(const char *DIRname, int lng, int acc, int lnk);
void aux_printFileInfo(struct dirent *file, struct stat *st, int lng, int acc, int lnk);