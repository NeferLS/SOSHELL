#pragma once

#include "types.h"

typedef struct fNode* fPosL;

typedef struct fNode{
  int df;
  char file_name[MAX_SIZE];
  char md[3];
  fPosL next;
}fNode;

typedef struct {
    fNode *head;       // Puntero al primer elemento de la lista
    int nm_elements;   // Contador de archivos en la lista
} fList;

bool isEmptyFileList(fList L);
void initFileList(fList *L);
void insertFile(fList *L, int df, const char file_name[], const char md[]);
void deleteFileinFileList(fList *L, int df);
void clearFileList(fList *L);
void printFiles(fList *L);
void closeFile(fList *L, int df);
void dupFile(fList *L, int df);
char *getFileName(fList *L, int df);
