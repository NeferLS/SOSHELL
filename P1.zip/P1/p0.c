/*
Autor 1: Pablo Fernandez Marti
Login 1: pablo.fernandez8@udc.es

Autor 2: Nefer Labrada Suarez
Login 2: nefer.suarez@udc.es
*/

#include "p0.h" 
#include "HistoList.h"
#include "fileList.h"

hList HIS;
fList FILELIST;

// obtener el pid con una llamada al sistema
void Cmd_pid(char *tr[]) {
    printf("PID del proceso: %d\n", getpid());
}

// obtener el ppid con una llamada al sistema
void Cmd_ppid(char *tr[]) {
    printf("PID del proceso padre: %d\n", getppid());
}

//imprime los autores. Si se usa el -l, los logins. Si se usa el -n, los nombres. Si no, todo.
void Cmd_authors(char *tr[]) {

    if (tr[0] == NULL)
    {
        printf("nefer.suarez@udc.es\npablo.fernandez8@udc.es\nNefer Labrada Suarez\nPablo Fernandez Marti\n");
    } else if (strcmp(tr[0], "-l") == 0) {
        printf("nefer.suarez@udc.es\npablo.fernandez8@udc.es\n");
    } else if (strcmp(tr[0], "-n") == 0) {
        printf("Nefer Labrada Suarez\nPablo Fernandez Marti\n");
    } else { 
        printf("sso: el argumento para 'authors' no es válido. Intente (-l)(-n) \n");
    }
    
}

// Indica, con una llamada al sistema, el directorio actual. 
//Se puede cambiar a un directorio existente o volver al anterior
void Cmd_chdir(char *tr[]) {
    char dir[MAX_COMM];
    if (tr[0] == NULL) {
        if (getcwd(dir, MAX_COMM) != NULL) {
            printf("Directorio actual: %s\n", dir);
        } else {
            perror("Error obteniendo el directorio actual");
        }
    } else if (chdir(tr[0]) == -1) {
        perror("Ha sido imposible cambiar de directorio");
    }
}

void Cmd_cwd(char *tr[]){
    if(tr[1] == NULL)
        Cmd_chdir(NULL);
}

// Sale del shell con una llamada al sistema.
void Cmd_exit(char *tr[]) {
    if (isEmptyFileList(FILELIST) || isEmptyHistoricList(HIS))
    {
        exit(0);
    } else { // si quedan listas con objetos, las borra antes de salir
        clearHistoricList(&HIS);
        clearFileList(&FILELIST);
        exit(0);
    } 
}

//obtiene la fecha actual mediante llamadas al sistema
void Cmd_date(char *tr[]) {
    time_t now = time(NULL);
    struct tm *local = localtime(&now);

    if (tr[0] == NULL){
        perror("sso: comando no encontrado:\n");
    } else if (strcmp(tr[0], "-d") == 0) { // time -d muestra la fecha
        printf("%02d/%02d/%d\n", local->tm_mday, local->tm_mon + 1, local->tm_year + 1900);
    } else if (strcmp(tr[0], "-t") == 0) { // time -t muestra la hora
        printf("%02d:%02d:%02d\n", local->tm_hour, local->tm_min, local->tm_sec);
    } else { 
        printf("sso: el argumento para 'date' no es válido. Intente (-d)(-t) \n");
    }
}

// muestra el historial de comandos usados
void Cmd_history(char *tr[]){
    if (tr[0] == NULL) { // si solo se pone historic, imprime la lista
        printf("\nHistorial de comandos\n");
        printHistoricList(&HIS, 0);
    } else { // caso historic N
        int N = atoi(tr[0]);
        if (N > 0) {  // Comprobamos que no tenga - delante
            char *command = getHistoricItem(&HIS, N); 
            if (command != NULL) { // Mientras sea valido el comando
                printf("Repitiendo el comando número %d del historial: %s\n", N, command);
                char *args[MAX_COMM / 2];
                funcBreakLine(command, args);  
                DoCommand(args); // repetimos el comando con esta funcion
            }
        } else if (N < 0) { // Si tiene un - delante, imprimimos los ultimos N
            N = -N;  
            printf("\nMostrando los últimos %d comandos del historial\n", N);
            printHistoricList(&HIS, -N); 
        } else { 
            perror("Argumento no válido para 'historic' ");
        }
    }
}

// listado de las funciones y lo que hacen
void Cmd_help(char *tr[]) {
    char *comandos[] = {
        "authors            - Imprime la lista de todos los autores (-p) y sus logins (-l).",
        "pid                - Imprime el PID del proceso que ejecuta al shell.",
        "ppid               - Imprime el PPID del proceso que ejecuta al shell.",
        "cd                 - Cambia el directorio actual de trabajo a 'dir'. Si no tiene argumentos, solo imprime el directorio actual.",
        "date                   - Imprime la fecha actual.\n\t\tdate -t      - Imprime el tiempo actual en formato hh:mm:ss\n\t\tdate -d      - Imprime la fecha actual en formato DD/MM/YYYY",
        "historic           - Imprime el histórico de comandos ejecutados por el shell.\n\t\thistoric N      - Imprime el comando numero N\n\t\thistoric -N      - Imprime los ultimos N comandos",
        "open [file] modo   - Abre un archivo y lo añade a la lista de abiertos. Los modos disponibles son:\n\t\tcr      - Crear un archivo si no existe\n\t\tap      - Abre un archivo para agregar datos\n\t\tex      - Crear un archivo de forma exclusiva\n\t\tro      - Abrir en forma lectura\n\t\trw      - Abrir en forma lectura y escritura\n\t\two      - Abrir en forma escritura\n\t\ttr      - Trunca el archivo a una tamaño de 0 al abrirlo",
        "close [df]         - Cierra el descriptor de archivo 'df'.",
        "dup [df]           - Duplica el descriptor de archivo 'df'.",
        "infosys            - Imprime información sobre la máquina.",
        "help [cmd]         - Muestra una lista de comandos disponibles o el uso de uno específico.",
        "quit/exit/bye      - Sale del programa.",
        NULL 
    };
    if (tr == NULL || tr[0] == NULL) {
        printf("Lista de comandos disponibles:\n");
        for (int i = 0; comandos[i] != NULL; i++) {
            printf(" - %s\n", comandos[i]);
        }
        return;
    }
    for (int i = 0; comandos[i] != NULL; i++) {
        if (strstr(comandos[i], tr[0]) != NULL) {
            printf("%s\n", comandos[i]);
            return;
        }
    }
    printf("Comando '%s' no reconocido. Usa 'help' para ver la lista de comandos disponibles.\n", tr[0]);
}

// Imprime la informacion del sistema con una llamada al sistema
void Cmd_infosys(char *tr[]){
    struct utsname sysInfo;

    if (uname(&sysInfo)==-1){
        perror("Error al obtener la información del sistema:\n");
        return;
    }

    printf("\nInformacion del sistema\n\n");
    printf("Sistema operativo: %s\n",sysInfo.sysname);
    printf("Nombre del nodo: %s\n",sysInfo.nodename);
    printf("Version del sistema operativo: %s\n",sysInfo.release);
    printf("Version del kernel: %s\n",sysInfo.version);
    printf("Arquitectura de la maquina: %s\n",sysInfo.machine);
}

// Abre un archivo con un modo a especificar.
void Cmd_open(char *tr[]) {
    int i, df, mode = 0;
    char modo_str[50] = ""; 

    if (tr[0] == NULL) { // si solo ponemos open
        printFiles(&FILELIST); 
        return;
    }
    if (tr[1] == NULL) { // si ponemos open [file] pero no ponemos modo
        printf("Error: Debe especificar al menos un modo de acceso. Use 'help' para más información.\n");
        return;
    }
    // si ponemos open [file] mode, igual esto hay que cambiarlo
    for (i = 1; tr[i] != NULL; i++) {
        if (!strcmp(tr[i], "cr")) { mode |= O_CREAT; strcat(modo_str, "c"); }
        else if (!strcmp(tr[i], "ex")) { mode |= O_EXCL; strcat(modo_str, "e"); }
        else if (!strcmp(tr[i], "ro")) { mode |= O_RDONLY; strcat(modo_str, "r"); }
        else if (!strcmp(tr[i], "wo")) { mode |= O_WRONLY; strcat(modo_str, "w"); }
        else if (!strcmp(tr[i], "rw")) { mode |= O_RDWR; strcat(modo_str, "rw"); }
        else if (!strcmp(tr[i], "ap")) { mode |= O_APPEND; strcat(modo_str, "a"); }
        else if (!strcmp(tr[i], "tr")) { mode |= O_TRUNC; strcat(modo_str, "t"); }
        else { 
            printf("Error: Modo de acceso '%s' no válido.\n", tr[i]);
            return;
        }
    }
    if ((df = open(tr[0], mode, 0644)) == -1) {
        perror("Imposible abrir fichero");
    } else {
        insertFile(&FILELIST, df, tr[0], modo_str);
        printf("Archivo '%s' abierto con descriptor %d en modo %s.\n", tr[0], df, modo_str);
    }
}

// Duplica un comando por su df.
void Cmd_dup(char *tr[]) {
    int df, duplicado;

    // Si el df es valido y no hay mas argumentos que dup
    if (tr[0] == NULL || (df = atoi(tr[0])) < 0) {
        printFiles(&FILELIST);
        return;
    }

    // duplica el descriptor
    duplicado = dup(df);
    if (duplicado == -1) {
        perror("Error al duplicar el descriptor");
        return;
    }

    // guarda el comando por su dif
    char *fileName = getFileName(&FILELIST, df);
    if (fileName == NULL) {
        printf("No se encontró el archivo a duplicar\n");
        return;
    }
    
    // reintegra el df a la lista, ahora duplicado
    insertFile(&FILELIST, duplicado, fileName, "dup");
    printf("Descriptor %d duplicado. Nuevo descriptor: %d.\n", df, duplicado);
}

// Cierra los archivos abiertos
void Cmd_close(char *tr[]) {
    int df;
    if (tr[0] == NULL) { // si solo se pone close
        printFiles(&FILELIST);
        return;
    }
    df = atoi(tr[0]);

    // comprueba si el argumento no es un número o si es menor q 0
    if (tr[0][0] < '0' || tr[0][0] > '9' || df < 0) {
        printf("Error: Descriptor inválido. Debe ser un número.\n");
        return;
    }
    // comprueba si el descriptor está en la lista
    fPosL p = FILELIST.head;
    while (p != NULL) {
        if (p->df == df) {
            // si esta
            if (close(df) == -1) {
                perror("Imposible cerrar descriptor");
            } else {
                // elimina de la lista 
                if (p == FILELIST.head) {
                    FILELIST.head = p->next; 
                } else {
                    // enlazarlo con el anterior
                    fPosL prev = FILELIST.head;
                    while (prev->next != p) {
                        prev = prev->next;
                    }
                    prev->next = p->next;  
                }
                FILELIST.nm_elements--; 
                free(p);       
                printf("Archivo con descriptor %d cerrado.\n", df);
            }
            return;
        }
        p = p->next;
    }
    printf("Error: No se encontró el descriptor %d en los archivos abiertos.\n", df);
}

void Cmd_mkdir(char *tr[]){
    if (tr[0] == NULL)
    {
      printf("uso: mkdir [-pv crear, verbose] [-m modo] nombre_directorio ...");  
    }
    if (mkdir(tr[0], S_IRWXU | S_IRWXG | S_IRWXO) == -1) {
        printf("Error al crear el directorio: %s\n", strerror(errno));
    }
}


// definición del array de comandos
// si ponemos lo que hay en "", vamos a la funcion correspondiente
struct CMD C[] = {
    {"authors", Cmd_authors},
    {"pid", Cmd_pid},
    {"ppid", Cmd_ppid},
    {"cd", Cmd_chdir},
    {"exit", Cmd_exit},
    {"bye", Cmd_exit},
    {"quit", Cmd_exit},
    {"date", Cmd_date},
    {"help", Cmd_help},
    {"historic", Cmd_history},
    {"infosys", Cmd_infosys},
    {"open", Cmd_open},
    {"close", Cmd_close},
    {"dup", Cmd_dup},
    {"cwd", Cmd_cwd},
    {"mkdir", Cmd_mkdir},
    {NULL, NULL}
};

// permite leer y ejecutar el comando
void DoCommand(char *tr[]) {
    int i;
    char command[MAX_COMM] = "";

    if (tr[0] == NULL) { // solo el comando, sin parametros
        return;
    }
    for (i = 0; tr[i] != NULL; i++) { // concatena comando con parametros
        strcat(command, tr[i]);
        if (tr[i + 1] != NULL) {
            strcat(command, " ");
        }
    }
    insertHistoricItem(&HIS, command); // inserta en el historial el comando
    for (i = 0; C[i].name != NULL; i++) { // comprueba el nombre con lo que tenemos en la funcion del CMD
        if (!strcmp(tr[0], C[i].name)) {
            (*C[i].function)(tr + 1);
            return;
        } 
    }
    printf("sso: comando no encontrado: %s \n", tr[0]);//
}

// funcion para dividir las lineas
int funcBreakLine(char *line, char *pz[]) {
    int i = 1;
    if ((pz[0] = strtok(line, " \n\t")) == NULL)
        return 0;
    while ((pz[i] = strtok(NULL, " \n\t")) != NULL)
        i++;
    return i;
}

int main(int argc, char *argv[]) {
    char line[MAX_COMM];
    char *pcs[MAX_COMM / 2]; 

    initHistoricList(&HIS); // lista de comandos vacia
    initFileList(&FILELIST); // lista de ficheros vacia

    while (1) {
        printf("(SO) user@Users-computer >> ");
        fgets(line, MAX_COMM, stdin);
        if (funcBreakLine(line, pcs) == 0) {  // Si no hay entrada válida
            continue;
        }
        DoCommand(pcs);
    }
}
