#include "fileList.h"

bool isEmptyFileList(fList L){
  return L.head == NULL;
}

//inicializamos funcion
void initFileList(fList *L){
    L->head = NULL;
    L->nm_elements = 0;
}
//insertar funcion
void insertFile(fList *L, int df, const char file_name[], 
  const char md[]){

      // crea nodo vacio
      fNode *newFile = (fNode*)malloc(sizeof(fNode));

      if (newFile == NULL){ // si no se pudo
          perror("Error al asignar memoria para le archivo");
          return;
      }

      // le ponemos los datos de df y nombre
      newFile->df = df;
      strncpy(newFile->file_name, file_name, sizeof(newFile->file_name) - 1);
      newFile->file_name[sizeof(newFile->file_name) - 1] = '\0'; 

      strncpy(newFile->md, md, sizeof(newFile->md) - 1);
      newFile->md[sizeof(newFile->md) - 1] = '\0';
      newFile->next = NULL;
      L->nm_elements++; // aumentamos el numero de elementos de la lista

      if(L->head == NULL){
          L->head = newFile; // si es el primer elemento, el header apunta a ese
      } else{
          fPosL p = L->head;
          while (p->next != NULL){
            p = p->next;
          }
          p->next = newFile; // si no, lo coloca en el siguiente
          
      } 
  }

// elimina todos los elementos de la lista
void clearFileList(fList *L){
    if(L->head == NULL){
        printf("La lista no tiene elementos\n");
        return;
    }
    fPosL p = L->head;
    fPosL temp;
    while (p != NULL){
        temp = p->next; 
        close(p->df);
        free(p);  
        p = temp;
    }
    //lista vacia al final
    L->head = NULL;
    L->nm_elements = 0;
}

// imprime los elementos de la lista
void printFiles(fList *L){
    if (L->head == NULL){
        printf("No hay ficheros abiertos\n");
        return;
    }
    fPosL p = L->head;
    printf("Escoja el archivo abierto a cerrar:\n");
    while (p != NULL)
    {
        printf("%s || %s [%d]\n", p->md, p->file_name, p->df);
        p = p->next;
    }
}

// cierra un archivo en concreto
void closeFile(fList *L, int df){
  if(L->head==NULL){
    printf("La lista de archivos abiertos esta vacia.\n");
    return;
  }
  
  fPosL p=L->head;
  fPosL prev=NULL;
  
  while(p != NULL && p->df != df){
    prev=p;
    p=p->next;
  }
  
  if(p==NULL){
    printf("No se encontro ningun archivo con el descriptor %d.\n", df);
    return;
  }
  
  if(close(p->df)==-1){
    perror("(perror) Error al cerrar el archivo: ");
    return;
  }
  
  if(prev==NULL){
    L->head=p->next;
  }else{
    prev->next=p->next;
  }
  
  free(p);
  printf("El archivo con el descriptor %d ha sido cerrado y eliminado de la lista de archivos abiertos.\n",df);
}

// duplica un archivo
void dupFile(fList *L, int df){
  if(L->head==NULL){
    printf("La lista de archivos abiertos esta vacia.\n");
    return;
  }
  
  fPosL p=L->head;

  while(p != NULL && p->df != df){
    p=p->next;
  }
  
  if(p==NULL){
    printf("No se encontro ningun archivo con el descriptor %d.\n", df);
    return;
  }
  
  //duplicar el descriptor de archivo
  int newDf= dup(p->df);
  if(newDf==-1){
    perror("(perror) Error al duplicar el descriptor de archivo: ");
    return;
  }

  insertFile(L, newDf, p->file_name, p->md);
  printf("El descriptor %d ha sido duplicado. Nuevo descriptor: %d.\n",df,newDf);
}

// consigue el nombre de un archivo gracias a su df
char *getFileName(fList *L, int df) {
    fPosL p = L->head; 

    while (p != NULL) {
        if (p->df == df) { 
            return p->file_name; 
        }
        p = p->next;
    }
    return NULL; 
}