void Cmd_chdir(char *tr[]) {
    char dir[MAX_COMM];
    if (tr[0] == NULL) {
        if (getcwd(dir, MAX_COMM) != NULL) {
            printf("Directorio actual: %s\n", dir);
        } else {
            perror("Error obteniendo el directorio actual");
        }
    } else if (chdir(tr[0]) == -1) {
        perror("Ha sido imposible cambiar de directorio");
    }
}