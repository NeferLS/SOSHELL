#include "types.h"

typedef char command[MAX_COMM];

struct CMD {
    char *name;
    void (*function)(char **);  // Puntero a función
};

void Cmd_pid(char *tr[]);
void Cmd_ppid(char *tr[]);
void Cmd_authors(char *tr[]);
void Cmd_chdir(char *tr[]);
void Cmd_exit(char *tr[]);
void Cmd_date(char *tr[]);
void Cmd_history(char *tr[]);
void Cmd_help(char *tr[]);
void Cmd_infosys(char *tr[]);
void Cmd_open(char *tr[]);
void Cmd_dup(char *tr[]);
void Cmd_close(char *tr[]);
void DoCommand(char *tr[]);
int funcBreakLine(char *line, char *pz[]);